package Control;

public class Main {
		public static void main(String args[]){
			ApplicationStart app = new ApplicationStart();
		}
}

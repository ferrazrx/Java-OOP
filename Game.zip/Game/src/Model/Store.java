package Model;

import java.util.ArrayList;

public class Store {
	
	public void processItem(Player player){
		
	}
	
}
